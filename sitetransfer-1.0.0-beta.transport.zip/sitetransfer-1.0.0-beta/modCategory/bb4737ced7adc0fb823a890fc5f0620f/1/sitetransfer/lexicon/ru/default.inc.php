<?php
include_once 'setting.inc.php';

$_lang['sitetransfer'] = 'siteTransfer';
$_lang['sitetransfer_menu_desc'] = 'Подготовить MODX к переносу на другой сервер';
$_lang['sitetransfer_update'] = 'Перенести сайт';
$_lang['sitetransfer_intro_msg'] = 'После нажатия кнопки «Создать архив», будет создан дамп базы данных и архив файлов сайта. Их можно будет перенести на другой сервер.';
$_lang['sitetransfer_update_start'] = 'Создать архив';
$_lang['sitetransfer_update_started'] = 'Начинаем подготовку. Ждите...';
$_lang['sitetransfer_configs_edited'] = 'Отредактировали файлы-конфиги. Ждите...';
$_lang['sitetransfer_dump_created'] = 'Дамп базы данных создан. Ждите...';
$_lang['sitetransfer_files_archived'] = 'Файлы сайта заархивированы. Ждите...';
$_lang['sitetransfer_sitearchive_created'] = 'Скачиваем архив для переноса сайта. Ждите...';
$_lang['sitetransfer_remove_transfer'] = 'Удалить архив';
$_lang['sitetransfer_finish'] = 'Готово. Когда архив скачается, нажмите «Удалить архив»';
