<?php
include_once 'setting.inc.php';

$_lang['sitetransfer'] = 'siteTransfer';
$_lang['sitetransfer_menu_desc'] = 'Transfer MODX site';
$_lang['sitetransfer_update'] = 'Transfer site';
$_lang['sitetransfer_intro_msg'] = 'Create database dump and file archive';
$_lang['sitetransfer_update_start'] = 'Start transfer';
$_lang['sitetransfer_update_started'] = 'Preparing. Wait...';
$_lang['sitetransfer_configs_edited'] = 'Configs are edited. Wait...';
$_lang['sitetransfer_dump_created'] = 'Database dump created. Wait...';
$_lang['sitetransfer_files_archived'] = 'Files are archived. Wait...';
$_lang['sitetransfer_sitearchive_created'] = 'Downloading transfer archive. Wait...';
$_lang['sitetransfer_remove_transfer'] = 'Remove archive';
$_lang['sitetransfer_finish'] = 'Done. Press «Remove archeve» when download complete.';
