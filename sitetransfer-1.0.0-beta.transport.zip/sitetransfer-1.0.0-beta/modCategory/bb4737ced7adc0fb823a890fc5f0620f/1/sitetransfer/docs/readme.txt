--------------------
siteTransfer
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

MODX addon for transfer MODX site.

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/ilyautkin/siteTransfer